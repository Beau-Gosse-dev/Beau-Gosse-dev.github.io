// Expansion-band cleaning fixture. Units: mm. Prototype; verify fit before use.
// Export part="base", "inserts", "insert", or "assembly".
part = "assembly";
slot_width = 18;              // nominal body-passage width
slot_clearance = 0.4;         // added to nominal slot width
socket_clearance = 0.5;       // total clearance around 4 mm insert
band_path = 254;             // approximate arc between gate centerlines
opening_angle = 30;
height = 34;
$fn = 160;
R = band_path / ((360-opening_angle)*PI/180);
gate_length=14;
gate_thickness=4;
gate_bottom=3.2;
band_center=17;

module arc_ring(z,h) {
 translate([0,0,z]) rotate([0,0,opening_angle/2])
 rotate_extrude(angle=360-opening_angle)
 translate([R-2.8,0]) square([2.8,h]);
}
module gate_frame(a) {rotate([0,0,a]) translate([R-12,-2,gate_bottom]) children();}
module base() {
 difference() {
  union() {
   arc_ring(0,3); arc_ring(height-3,3);
   for(a=[23:19.625:337]) rotate([0,0,a])
    translate([R-1.5,0,2]) cylinder(r=1.5,h=height-4,$fn=32);
   for(a=[opening_angle/2,360-opening_angle/2])
    rotate([0,0,a]) translate([R-13.25,-5.25,0]) cube([17.5,10.5,6]);
  }
  for(a=[opening_angle/2,360-opening_angle/2])
   rotate([0,0,a]) translate([R-12-socket_clearance/2,-2-socket_clearance/2,3])
    cube([gate_length+socket_clearance,gate_thickness+socket_clearance,height]);
 }
}
// Slot is open radially outward. Two axial walls retain the wider end fitting.
module gate(w=18) {
 difference() {
  cube([gate_length,gate_thickness,height-gate_bottom]);
  translate([8,-1,band_center-gate_bottom-(w+slot_clearance)/2])
   cube([gate_length,gate_thickness+2,w+slot_clearance]);
  // Recessed size label on upper face when printed flat.
  translate([4,gate_thickness+0.1,14]) rotate([90,0,0])
   linear_extrude(height=0.7) text(str(w),size=3,halign="center",valign="center",font="Liberation Sans:style=Bold");
 }
}
module flat_gate(w) {translate([0,height-gate_bottom,0]) rotate([90,0,0]) gate(w);}
if(part=="base") base();
if(part=="insert") flat_gate(slot_width);
if(part=="inserts") for(i=[0:4]) for(j=[0:1]) translate([i*19,j*36,0]) flat_gate(16+i);
if(part=="assembly") {
 color("LightSlateGray") base();
 for(a=[opening_angle/2,360-opening_angle/2]) color("DarkOrange") gate_frame(a) gate(slot_width);
}
